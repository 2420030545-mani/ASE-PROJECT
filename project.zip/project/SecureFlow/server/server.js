const express = require('express');
const path = require('path');
const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.static(path.join(__dirname, '..', 'public')));

// In‑memory store for commits
const commits = {};
let nextId = 1;

// Helper functions (mirroring the original JS logic)
function analyze(f) {
  const fac = [
    ['Change size', Math.min(f.lines / 800, 1) * 15],
    ['Sensitive code touched', f.sensitive ? 18 : 0],
    ['New dependencies', Math.min(f.deps, 6) / 6 * 10],
    ['Highest CVSS', f.cvss / 10 * 25],
    ['Known exploited CVE', f.exploited ? 22 : 0],
    ['Secret in commit', f.secret ? 20 : 0],
    ['Internet‑facing service', f.exposed ? 8 : 0]
  ];
  const score = Math.min(100, Math.round(fac.reduce((a, b) => a + b[1], 0)));
  return { fac, score, cat: score < 30 ? 'Low' : score < 60 ? 'Medium' : 'High' };
}

function findings(f) {
  const r = [];
  if (f.secret) r.push(['Hard‑coded API key', 'Secrets', 'Critical', .03]);
  if (f.exploited) r.push(['Dependency with known exploited CVE', 'SCA', 'Critical', .05]);
  else if (f.cvss >= 7) r.push([`Vulnerable dependency (CVSS ${f.cvss.toFixed(1)})`, 'SCA', 'High', .15]);
  else if (f.cvss > 0) r.push([`Outdated dependency (CVSS ${f.cvss.toFixed(1)})`, 'SCA', 'Medium', .2]);
  if (f.sensitive) r.push(['Possible injection in request handler', 'SAST', 'Medium', .3]);
  if (f.lines > 400) r.push(['Large change with low test coverage', 'SAST', 'Low', .35]);
  if (f.exposed) r.push(['Service exposed through public ingress', 'IaC', 'Low', .25]);
  if (f.lines > 50) r.push(['Sensitive‑looking string in debug log', 'SAST', 'Low', .82]);
  return r.map(([t, tool, sev, fp]) => ({ t, tool, sev, fp }));
}

function decide(f, a, fs) {
  const hasCrit = fs.some(x => x.sev === 'Critical' && x.fp < .5);
  const rules = [];
  if (f.secret) rules.push('Secret detected in commit');
  if (f.exploited) rules.push('Exploitable critical dependency');
  if (a.cat === 'High' && !rules.length) rules.push('High risk score with no security approval recorded');
  if (rules.length || (hasCrit && a.cat === 'High')) return { v: 'Block', rules };
  if (a.cat === 'Medium') return { v: 'Conditional', rules: ['Medium risk, no critical findings: canary only'] };
  return { v: 'Approve', rules: ['Low risk and all checks passed'] };
}

// API endpoints ------------------------------------------------------------
app.post('/api/commit', (req, res) => {
  const id = (nextId++).toString();
  const payload = { ...req.body, id, created: new Date().toISOString() };
  commits[id] = payload;
  res.json({ id });
});

app.get('/api/scan/:id', (req, res) => {
  const commit = commits[req.params.id];
  if (!commit) return res.status(404).json({ error: 'unknown commit' });
  const fs = findings(commit);
  res.json({ findings: fs });
});

app.get('/api/risk/:id', (req, res) => {
  const commit = commits[req.params.id];
  if (!commit) return res.status(404).json({ error: 'unknown commit' });
  const a = analyze(commit);
  res.json(a);
});

app.get('/api/policy/:id', (req, res) => {
  const commit = commits[req.params.id];
  if (!commit) return res.status(404).json({ error: 'unknown commit' });
  const a = analyze(commit);
  const fs = findings(commit);
  const d = decide(commit, a, fs);
  res.json(d);
});

app.listen(PORT, () => {
  console.log(`SecureFlow server listening on http://localhost:${PORT}`);
});
