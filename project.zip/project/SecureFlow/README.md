# SecureFlow – Adaptive DevSecOps Console

## Overview
SecureFlow is a **real‑world, full‑stack web application** that demonstrates a complete DevSecOps pipeline for a software change.  It mimics the flow used by modern CI/CD systems:

1. **Commit ingestion** – a simulated webhook receives change metadata.
2. **Static analysis & dependency scanning** – SAST, SCA, container, IaC scans.
3. **AI‑driven risk scoring** – a lightweight model calculates a risk score based on change size, CVSS, secrets, etc.
4. **Policy gate** – rules decide whether the change can be deployed, must go through a canary, or be blocked.
5. **Canary / full deployment** – a toy deployment service shows the final outcome.

The UI (see `public/index.html`) mirrors the HTML you supplied.  The JavaScript has been refactored to call **real HTTP endpoints** on a small Express server (`server.js`).  This gives the project a proper client‑server architecture that a final‑year student can extend (e.g. plug in real scanners, add authentication, store results in a DB, etc.).

---

## Project Structure
```
SecureFlow/
├─ public/                # Front‑end (static assets)
│   ├─ index.html        # UI – adapted from the reference HTML
│   └─ app.js            # Front‑end logic (fetches API endpoints)
├─ server/                # Back‑end (Node.js + Express)
│   ├─ server.js         # Minimal API implementation
│   └─ data/             # Stub data / mock scan results (optional)
├─ package.json           # NPM/Yarn manifest
├─ .gitignore            # Ignores node_modules, logs, etc.
└─ README.md              # This document
```

---

## Setup & Run (Windows + Node.js)
1. **Install Node.js** (v20 or later) from https://nodejs.org.
2. Open PowerShell in the project root (`SecureFlow`).
3. Install dependencies:
   ```powershell
   npm install
   ```
4. Start the server (it will serve the UI and API):
   ```powershell
   npm start
   ```
5. Open a browser at <http://localhost:3000>.  You will see the SecureFlow console.  Play with the presets or custom values and watch the pipeline progress.

---

## Core Components
### 1. Front‑end (`public/app.js`)
* Reads the form values.
* Calls the back‑end API in order:
  1. `POST /api/commit` – registers the change and returns an ID.
  2. `GET /api/scan/:id` – returns a list of fake findings.
  3. `GET /api/risk/:id` – returns a risk score + category.
  4. `GET /api/policy/:id` – returns the decision (Approve / Conditional / Block) and the applied rules.
* Updates the UI (track bar, tables, pills) exactly like the reference demo.

### 2. Back‑end (`server/server.js`)
* **Express** server listening on port 3000.
* Endpoints:
  ```js
  POST   /api/commit   // body: {form}
  GET    /api/scan/:id
  GET    /api/risk/:id
  GET    /api/policy/:id
  ```
* The logic mirrors the original JavaScript functions (`analyze`, `findings`, `decide`).  It returns JSON payloads so the UI can stay framework‑agnostic.
* All data is kept **in‑memory** for the demo – perfect for a student project.  Adding a database (SQLite, PostgreSQL, …) is a natural next step.

---

## Extending the Project (Ideas for a Final‑Year Thesis)
| Area | What to Add |
|------|------------|
| **Real Scanners** | Integrate open‑source SAST (Bandit, SonarQube) or SCA (OWASP Dependency‑Check). |
| **AI Model** | Replace the simple heuristic with a small TensorFlow/PyTorch model trained on historical risk data. |
| **Authentication** | Add OAuth2 / OIDC login (Google, GitHub) and store per‑user pipelines. |
| **Persistent Storage** | Use a relational DB to keep commit metadata, scan results, policy decisions. |
| **CI/CD Integration** | Trigger the pipeline from a real GitHub webhook instead of the simulated UI. |
| **Dashboard** | Expand the “Dashboard” tab with charts (Chart.js) showing historical risk trends. |
| **Testing** | Write unit tests for the back‑end (`jest`) and end‑to‑end tests for the UI (Playwright). |
| **Containerisation** | Docker‑file for the whole stack, optionally orchestrate with Docker‑Compose/Kubernetes. |

---

## License
This starter project is released under the **MIT License** – feel free to fork, modify, and publish.

---

## Acknowledgements
* The original UI design is taken from the SecureFlow Adaptive DevSecOps Console you provided.
* The risk‑scoring algorithm is a simplified version of common industry heuristics.
```
