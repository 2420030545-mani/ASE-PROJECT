const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => Array.from(document.querySelectorAll(selector));

const formEls = {
  service: $('#service'),
  lines: $('#lines'),
  deps: $('#deps'),
  cvss: $('#cvss'),
  sensitive: $('#sensitive'),
  secret: $('#secret'),
  exploited: $('#exploited'),
  exposed: $('#exposed'),
  spike: $('#spike'),
  lv: $('#lv'),
  cv: $('#cv')
};

const presetData = {
  'Low-risk patch': {
    service: 'user-service',
    lines: 120,
    deps: 1,
    cvss: 3.2,
    sensitive: false,
    secret: false,
    exploited: false,
    exposed: false,
    spike: false
  },
  'Canary release': {
    service: 'order-service',
    lines: 280,
    deps: 3,
    cvss: 6.1,
    sensitive: true,
    secret: false,
    exploited: false,
    exposed: true,
    spike: true
  },
  'High-risk hotfix': {
    service: 'payment-service',
    lines: 620,
    deps: 6,
    cvss: 9.1,
    sensitive: true,
    secret: true,
    exploited: true,
    exposed: true,
    spike: true
  }
};

const state = {
  history: JSON.parse(localStorage.getItem('secureflow-history') || '[]')
};

function fillForm(data) {
  formEls.service.value = data.service;
  formEls.lines.value = data.lines;
  formEls.deps.value = data.deps;
  formEls.cvss.value = data.cvss;
  formEls.sensitive.checked = Boolean(data.sensitive);
  formEls.secret.checked = Boolean(data.secret);
  formEls.exploited.checked = Boolean(data.exploited);
  formEls.exposed.checked = Boolean(data.exposed);
  formEls.spike.checked = Boolean(data.spike);
  syncLabels();
}

function syncLabels() {
  formEls.lv.textContent = formEls.lines.value;
  formEls.cv.textContent = Number(formEls.cvss.value).toFixed(1);
}

function buildPresets() {
  const container = $('#presets');
  Object.entries(presetData).forEach(([label, data]) => {
    const button = document.createElement('button');
    button.type = 'button';
    button.textContent = label;
    button.addEventListener('click', () => fillForm(data));
    container.appendChild(button);
  });
}

function setTab(name) {
  const sections = {
    run: $('#run'),
    dash: $('#dash')
  };

  Object.entries(sections).forEach(([key, el]) => {
    const show = key === name;
    el.classList.toggle('hid', !show);
  });

  $$('[role="tab"]').forEach((tab) => {
    const selected = tab.dataset.t === name;
    tab.setAttribute('aria-selected', String(selected));
  });
}

function renderTrack(stepIndex) {
  const labels = ['Commit', 'Scan', 'Risk', 'Policy', 'Deploy'];
  const html = labels.map((label, index) => {
    const classes = ['st'];
    if (index < stepIndex) classes.push('done');
    if (index === stepIndex) classes.push('on');
    return `<div class="${classes.join(' ')}"><i>${index + 1}</i><span>${label}</span></div>`;
  }).join('');
  $('#track').innerHTML = html;
}

function renderRiskFactors(factors) {
  const max = Math.max(...factors.map(([, value]) => value), 100);
  const rows = factors.map(([label, value]) => {
    const width = Math.max(8, (value / max) * 100);
    return `
      <div class="fr">
        <span>${label}</span>
        <div class="fb" style="width:${width}%"></div>
        <span>${Math.round(value)}%</span>
      </div>
    `;
  }).join('');
  return rows;
}

async function runPipeline() {
  const button = $('#go');
  button.disabled = true;
  renderTrack(0);
  $('#msg').textContent = 'Submitting the change to the SecureFlow pipeline...';

  try {
    const form = {
      service: formEls.service.value,
      lines: Number(formEls.lines.value),
      deps: Number(formEls.deps.value),
      cvss: Number(formEls.cvss.value),
      sensitive: formEls.sensitive.checked,
      secret: formEls.secret.checked,
      exploited: formEls.exploited.checked,
      exposed: formEls.exposed.checked,
      spike: formEls.spike.checked,
    };

    const commitRes = await fetch('/api/commit', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(form)
    });

    if (!commitRes.ok) {
      throw new Error('Unable to register the commit.');
    }

    const commit = await commitRes.json();
    renderTrack(1);
    $('#msg').textContent = `Commit registered as ${commit.id}. Running static and dependency scans...`;

    const [scanRes, riskRes, policyRes] = await Promise.all([
      fetch(`/api/scan/${commit.id}`),
      fetch(`/api/risk/${commit.id}`),
      fetch(`/api/policy/${commit.id}`)
    ]);

    if (!scanRes.ok || !riskRes.ok || !policyRes.ok) {
      throw new Error('Pipeline step failed.');
    }

    const scan = await scanRes.json();
    const risk = await riskRes.json();
    const policy = await policyRes.json();

    renderTrack(4);
    renderResults({ scan, risk, policy, form, id: commit.id });

    const result = {
      id: commit.id,
      service: form.service,
      score: risk.score,
      category: risk.cat,
      decision: policy.v,
      timestamp: new Date().toLocaleString()
    };

    state.history.push(result);
    localStorage.setItem('secureflow-history', JSON.stringify(state.history));
    renderDashboard();
    $('#msg').textContent = `Pipeline complete. ${policy.v} decision recorded for ${form.service}.`;
  } catch (error) {
    console.error(error);
    $('#msg').textContent = 'The pipeline hit an unexpected error. Please try again.';
    renderTrack(0);
  } finally {
    button.disabled = false;
  }
}

function renderResults({ scan, risk, policy, form, id }) {
  const riskHtml = `
    <div style="display:flex;justify-content:space-between;align-items:end;gap:16px;flex-wrap:wrap;">
      <div>
        <div class="big">${risk.score}</div>
        <div class="pill ${risk.cat}">${risk.cat}</div>
      </div>
      <div style="flex:1;min-width:200px">
        ${renderRiskFactors(risk.fac)}
      </div>
    </div>
  `;

  const scanRows = scan.findings.map((item) => `
    <tr>
      <td>${item.t}</td>
      <td>${item.tool}</td>
      <td class="sev-${item.sev}">${item.sev}</td>
      <td>${Number(item.fp * 100).toFixed(0)}%</td>
    </tr>
  `).join('');

  const scanHtml = `
    <table>
      <thead>
        <tr>
          <th>Finding</th>
          <th>Tool</th>
          <th>Severity</th>
          <th>False positive</th>
        </tr>
      </thead>
      <tbody>
        ${scanRows || '<tr><td colspan="4">No findings generated.</td></tr>'}
      </tbody>
    </table>
  `;

  const canaryHtml = form.spike
    ? `
      <div class="canary">
        <div class="ok">Canary passed</div>
        <div class="no">Error spike triggered</div>
      </div>
    `
    : `
      <div class="canary">
        <div class="ok">Canary passed</div>
        <div>Stable</div>
      </div>
    `;

  const policyHtml = `
    <div style="display:flex;justify-content:space-between;align-items:center;gap:16px;flex-wrap:wrap">
      <div>
        <div class="big">${policy.v}</div>
        <span class="pill ${policy.v}">${policy.v}</span>
      </div>
      <div style="min-width:220px;flex:1">
        <div class="note">Commit ID: ${id}</div>
        <div class="note">Service: ${form.service}</div>
      </div>
    </div>
    <ul>
      ${policy.rules.map((rule) => `<li>${rule}</li>`).join('') || '<li>No additional policy gates applied.</li>'}
    </ul>
    ${policy.v === 'Conditional' ? canaryHtml : ''}
  `;

  $('#o-risk').innerHTML = riskHtml;
  $('#o-scan').innerHTML = scanHtml;
  $('#o-pol').innerHTML = policyHtml;

  $('#c-risk').classList.remove('hid');
  $('#c-scan').classList.remove('hid');
  $('#c-pol').classList.remove('hid');
}

function renderDashboard() {
  const tiles = $('#tiles');
  const chart = $('#chart');
  const hist = $('#hist');

  if (!state.history.length) {
    tiles.innerHTML = `
      <div class="tile"><div>Avg risk</div><b>0</b></div>
      <div class="tile"><div>Approved</div><b>0</b></div>
      <div class="tile"><div>High risk</div><b>0</b></div>
      <div class="tile"><div>Recent</div><b>0</b></div>
    `;
    chart.innerHTML = '<p class="note">Run a pipeline to populate the risk history.</p>';
    hist.innerHTML = '<p class="note">No recent runs yet.</p>';
    return;
  }

  const avg = Math.round(state.history.reduce((sum, item) => sum + item.score, 0) / state.history.length);
  const approved = state.history.filter((item) => item.decision === 'Approve').length;
  const highRisk = state.history.filter((item) => item.category === 'High').length;
  const recent = state.history[state.history.length - 1]?.score ?? 0;

  tiles.innerHTML = `
    <div class="tile"><div>Avg risk</div><b>${avg}</b></div>
    <div class="tile"><div>Approved</div><b>${approved}</b></div>
    <div class="tile"><div>High risk</div><b>${highRisk}</b></div>
    <div class="tile"><div>Recent</div><b>${recent}</b></div>
  `;

  const maxScore = Math.max(100, ...state.history.map((item) => item.score));
  const recentRuns = state.history.slice(-8);
  chart.innerHTML = `
    <div style="display:flex;align-items:flex-end;gap:8px;height:180px;padding-top:16px;">
      ${recentRuns.map((item) => `
        <div style="flex:1;display:flex;flex-direction:column;align-items:center;gap:8px;min-width:40px;">
          <div style="width:100%;height:140px;display:flex;align-items:flex-end;justify-content:center;">
            <div style="width:100%;max-width:32px;height:${Math.max(12, (item.score / maxScore) * 100)}%;background:var(--ac);border-radius:6px 6px 0 0;display:block;"></div>
          </div>
          <small style="color:var(--mu)">${item.score}</small>
        </div>
      `).join('')}
    </div>
  `;

  hist.innerHTML = `
    <table>
      <thead>
        <tr>
          <th>Time</th>
          <th>Service</th>
          <th>Score</th>
          <th>Decision</th>
        </tr>
      </thead>
      <tbody>
        ${state.history.slice().reverse().map((item) => `
          <tr>
            <td>${item.timestamp}</td>
            <td>${item.service}</td>
            <td>${item.score}</td>
            <td><span class="pill ${item.decision}">${item.decision}</span></td>
          </tr>
        `).join('')}
      </tbody>
    </table>
  `;
}

function clearHistory() {
  state.history = [];
  localStorage.setItem('secureflow-history', '[]');
  renderDashboard();
}

function bindControls() {
  $('#go').addEventListener('click', runPipeline);
  $('#lines').addEventListener('input', syncLabels);
  $('#cvss').addEventListener('input', syncLabels);
  $('#clear').addEventListener('click', clearHistory);
  $('#clear').addEventListener('keydown', (event) => {
    if (event.key === 'Enter' || event.key === ' ') {
      event.preventDefault();
      clearHistory();
    }
  });

  $$('[role="tab"]').forEach((tab) => {
    tab.addEventListener('click', () => setTab(tab.dataset.t));
  });
}

function init() {
  buildPresets();
  fillForm(presetData['Low-risk patch']);
  bindControls();
  renderTrack(0);
  renderDashboard();
  setTab('run');
}

init();
